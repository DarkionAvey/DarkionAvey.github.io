filename = ARGV[0] || 'Coalesced.ini'

File.open(filename, "r:ascii-8bit") do |f|
  exit if f.read(4) != "\x1e\x00\x00\x00"
  data = Array.new
  i = 0
  until f.eof do
    data[i] = Hash.new
    data[i][:offset] = f.pos
    data[i][:name_len], data[i][:name], data[i][:data_len], 
    data[i][:data] = f.read.unpack('VZ*VZ*')
    f.seek((data[i][:offset] + data[i][:data].length + data[i][:name].length + 10))
    i += 1
  end
  data.each do |section|
    if section[:name_len] != (section[:name].length+1)
      section[:name_len] = (section[:name].length+1)
      $is_fixed ||= true
      puts "Fixing section name at 0x#{section[:offset].to_s(16)} ..."
    end
    if section[:data_len] != (section[:data].length+1)
      section[:data_len] = (section[:data].length+1)
      $is_fixed ||= true
      puts "Fixing section data at 0x" + (section[:offset] + 4 + section[:name_len]).to_s(16) + " ..."
    end
  end
  if $is_fixed
    puts "\nWriting fixed file to fix_#{filename}"
    output = "\x1e\x00\x00\x00"
    output << data.map {|section| [section[:name_len], section[:name], section[:data_len], section[:data]].pack('VZ*VZ*')}.join
    File.open("fix_#{filename}", 'wb') {|f| f.write(output) }
  end
end