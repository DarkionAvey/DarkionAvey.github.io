import java.io.File;

import javax.swing.JLabel;

import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.Prefs;
import ij.gui.Roi;
import ij.io.Opener;
import ij.measure.Measurements;
import ij.measure.ResultsTable;
import ij.plugin.Resizer;
import ij.plugin.filter.ParticleAnalyzer;
import ij.plugin.filter.PlugInFilter;
import ij.process.FloatProcessor;
import ij.process.ImageConverter;
import ij.process.ImageProcessor;
import ij.process.ImageStatistics;
import ij.process.ShortProcessor;

/**
 * This class implements utilizes ImageJ's threshold and particle analysis to
 * detect mouse location in CPP apparatus that's made from three compartments:
 * white, grey, and black. Since the mice we used were white, this class only
 * measures their presence in the grey and black compartments, then subtract the
 * time spent in each of the mentioned compartments to calculate the time in the
 * white compartment. Test time was fixed to 15 minutes.
 * 
 * 
 * Copyright - DarkionAvey / GPL license
 */

public class Main implements PlugInFilter, Measurements {

	ResultsTable table = new ResultsTable();
	Roi blackZone, greyZone, crop;
	int options = ParticleAnalyzer.SHOW_RESULTS | ParticleAnalyzer.SHOW_OUTLINES | ParticleAnalyzer.SHOW_SUMMARY;
	int blackCounter = 0, greyCounter = 0, outsideTheViewCounter = 0;
	ParticleAnalyzer analyzer;
	int analysisErrors = 0, bestAreaErrors = 0;

	@Override
	public void run(ImageProcessor arg0) {

	}

	private int getThresholdValue(ImagePlus imp, ImageProcessor ip) {
		ip.setThreshold(1, 255, ImageProcessor.BLACK_AND_WHITE_LUT);
		for (int i = 0; i < 255; i++) {
			double val = updatePercentiles(imp, ip, i);
			if (val <= 4) {
				return i;
			}
		}
		return 255;
	}

	double updatePercentiles(ImagePlus imp, ImageProcessor ip, int minThreshold) {

		ImageStatistics stats = ImageStatistics.getStatistics(ip, AREA + MIN_MAX + MODE, null);
		int minThresholdInt = (int) Math.round(minThreshold);
		if (minThresholdInt < 0)
			minThresholdInt = 0;
		if (minThresholdInt > 255)
			minThresholdInt = 255;
		int maxThresholdInt = 255;
		// System.out.println("stats " + stats);
		// System.out.println("histogram " + stats.histogram);
		// System.out.println("length " + stats.histogram.length);
		// System.out.println("ip.getMinThreshold() " + ip.getMinThreshold());
		// System.out.println("ImageProcessor.NO_THRESHOLD " +
		// ImageProcessor.NO_THRESHOLD);

		if (stats != null && stats.histogram != null && stats.histogram.length == 256
				&& ip.getMinThreshold() != ImageProcessor.NO_THRESHOLD) {
			int[] histogram = stats.histogram;
			int below = 0, inside = 0, above = 0;
			int minValue = 0, maxValue = 255;

			for (int i = minValue; i < minThresholdInt; i++)
				below += histogram[i];
			for (int i = minThresholdInt; i <= maxThresholdInt; i++)
				inside += histogram[i];
			for (int i = maxThresholdInt + 1; i <= maxValue; i++)
				above += histogram[i];
			int total = below + inside + above;
			// System.out.println("below " + below);
			// System.out.println("above " + above);
			// System.out.println("inside " + inside);
			// System.out.println("total " + total);

			// IJ.log("<"+minThresholdInt+":"+below+" in:"+inside+";
			// >"+maxThresholdInt+":"+above+" sum="+total);
			// int digits = imp.getCalibration() != null || (ip instanceof
			// FloatProcessor)
			// ? Math.max(Analyzer.getPrecision(), 2) : 0;

			return 100.0 * inside / total;

		}

		System.out.println("error thresholding -1");
		return -1;
	}

	long time;
	File workspace, input;
	final public boolean DEBUGGING_MODE = true;

	public void setWorkspace(File f) {
		workspace = f;
	}

	public void setInputFile(File f) {
		input = f;
	}

	final int maxDebugFrames = 500;
	static final int BYTE = 0, SHORT = 1, FLOAT = 2, RGB = 3;

	public void analyzeCurrentStack() {
		IJ.getImage().unlock();

		if (crop != null) {
			IJ.getImage().setRoi(crop);
			statusbar.setText("Cropping frames");

			new Resizer().run("crop");
		}
		statusbar.setText("Converting to gray scale");

		new ImageConverter(IJ.getImage()).convertToGray8();
		// IJ.showMessage("Error", greyZone.toString() + " " +
		// blackZone.toString());

		// ContrastEnhancer contrastEnhancer = new ContrastEnhancer();
		// contrastEnhancer.stretchHistogram(IJ.getImage(), 30);

		if (analyzer == null)
			analyzer = new ParticleAnalyzer(DEBUGGING_MODE ? ParticleAnalyzer.SHOW_OUTLINES : 0,
					RECT + AREA + CENTROID + PERIMETER, table, 1000, Integer.MAX_VALUE, 0.1, 1);

		ImageStack stack = IJ.getImage().getStack();
		int images = stack.getSize();
		// Calibration cal = IJ.getImage().getCalibration();
		ImagePlus image;
		// BackgroundSubtracter subtracter = new BackgroundSubtracter();
		ImageProcessor ip;

		File ws = new File(workspace, UI.stripExtension(input.getName()));
		if (!ws.exists())
			ws.mkdirs();
		File fOut = new File(ws, "debugging_" + UI.stripExtension(input.getName()));
		if (!fOut.exists())
			fOut.mkdirs();

		for (int stackLooper = 1; stackLooper < images; stackLooper++) {
			statusbar.setText("Analysing frame #" + stackLooper + " out of " + images);
			ip = stack.getProcessor(stackLooper);
			image = new ImagePlus(stack.getSliceLabel(stackLooper), ip);
			image.unlock();

			// IJ.run(image, "Enhance Contrast", "saturated=0.35");

			if (DEBUGGING_MODE && stackLooper < maxDebugFrames) {
				File pic = new File(fOut, "filename" + stackLooper + ".jpg");
				IJ.save(image, pic.getAbsolutePath());
			}

			// double val = updatePercentiles(image, ip, 255);
			//
			//

			// ip.setMinAndMax(min, max);
			ip.setThreshold(min, 255, ImageProcessor.BLACK_AND_WHITE_LUT);
			if (DEBUGGING_MODE && stackLooper < maxDebugFrames) {
				File pic = new File(fOut, "filename" + stackLooper + "_thresholded.jpg");
				IJ.save(image, pic.getAbsolutePath());
			}

			int imageType;
			if (ip instanceof ShortProcessor)
				imageType = SHORT;
			else if (ip instanceof FloatProcessor)
				imageType = FLOAT;
			else
				imageType = BYTE;

			ImageStatistics stats = image.getStatistics();

			boolean emptyImage = !(imageType != BYTE
					|| (stats.histogram[0] + stats.histogram[255] != stats.pixelCount));

			if (emptyImage) {
				outsideTheViewCounter++;
				continue;
			}

			// if (getThresholdValue(image, ip) == 255) {
			// outsideTheViewCounter++;
			// continue;
			//
			// }
			// subtracter.rollingBallBackground(ip, 100, false, false, false,
			// false, false);

			//
			// System.out.println("Threshold = " + p);
			// ip.setThreshold(min, 255, ImageProcessor.BLACK_AND_WHITE_LUT);
			//
			// ip.min(70);
			// if (!(ip instanceof ByteProcessor))
			// ip.resetMinAndMax();

			Prefs.blackBackground = true;
			IJ.run(image, "Make Binary", "");

			if (DEBUGGING_MODE && stackLooper < maxDebugFrames) {
				File pic = new File(fOut, "filename" + stackLooper + "_binary.jpg");
				IJ.save(image, pic.getAbsolutePath());
			}

			// subtracter.rollingBallBackground(ip, 100, false, false, false,
			// false, false);

			boolean error = false;
			table.reset();
			analyzer.setHideOutputImage(true);
			if (!analyzer.analyze(image, ip)) {
				// errors.add(stackLooper);
				// errorsNames.add(image.getTitle());
				// IJ.showMessage("Error", "An error has occurred ");
				error = true;
				// IJ.showMessage("Warning", "Detected more than one area");
				analysisErrors++;

			}

			if (!error) {

				// Line2D line1 = new Line2D.Float(100, 100, 200, 200);
				// Line2D line2 = new Line2D.Float(150, 150, 150, 200);

				float areas[] = table.getColumn(ResultsTable.AREA);
				float x = -10, y = -10;
				if (areas != null) {

					float centroidX[] = table.getColumn(ResultsTable.X_CENTROID);
					float centroidY[] = table.getColumn(ResultsTable.Y_CENTROID);

					float area = -1;
					int areaInt = -1;

					for (int i = 0; i < areas.length; i++) {
						float areaLoop = areas[i];
						if (areaLoop >= area) {
							area = areaLoop;
							areaInt = i;
						}
					}

					if (areaInt > -1) {

						x = centroidX[areaInt];
						y = centroidY[areaInt];

						if (greyZone.getBounds().contains(x, y)) {
							// IJ.showMessage("On grey zone");
							greyCounter++;
						} else
							blackCounter++;
					} else
						bestAreaErrors++;

				} else
					outsideTheViewCounter++;

				if (DEBUGGING_MODE && stackLooper < maxDebugFrames) {
					ImagePlus img = analyzer.getOutputImage();
					if (x > -1 && y > -1)
						img.getProcessor().drawOval(Math.round(x), Math.round(y), 5, 5);
					img.getProcessor().drawRoi(greyZone);
					img.getProcessor().drawRoi(blackZone);

					IJ.run(img, "Invert", "");
					IJ.save(img, new File(fOut.getAbsolutePath(), "filename" + stackLooper + "_debug.jpg")
							.getAbsolutePath());
				}

			} else
				analysisErrors++;

		}
		// StringBuilder sb = new StringBuilder();
		// for (String s : errorsNames) {
		// sb.append(s);
		// sb.append("\n");
		// }
		// IJ.showMessage("Analyzed " + images + " images.\nGrey: " +
		// greyCounter + ", black: " + blackCounter
		// + ", outside-the-box: " + outsideTheViewCounter + ".\n" +
		// (bestAreaErrors + analysisErrors)
		// + " errors had occured during the process, of which " +
		// bestAreaErrors
		// + " are erros related to area measurements, " + analysisErrors + "
		// analysis errors.\n");

		time = System.currentTimeMillis() - time;

		if (finishFinishAnalysisListener != null) {
			finishFinishAnalysisListener.onFinishedAnalysisEvent(outsideTheViewCounter, blackCounter, greyCounter,
					bestAreaErrors, analysisErrors, time, images);
		}
	}

	public void analyze() {
		analyzeCurrentStack();
		// if (IJ.getImage().getStack().getSize() > 1)
		// analyzeCurrentStack();
		// else
		// analyzeCurrentFolder();
	}

	public void analyzeCurrentFolder() {
		File[] s = dir.listFiles();
		if (s.length < 2)
			throw new IllegalArgumentException("Dir is null");
		for (int i = 0; i < s.length; i++) {
			Opener opener = new Opener();
			ImagePlus o = opener.openImage(s[i].getAbsolutePath());
			o.show();
			analyzeCurrentFolder(o, i);
		}

		if (finishFinishAnalysisListener != null) {
			finishFinishAnalysisListener.onFinishedAnalysisEvent(outsideTheViewCounter, blackCounter, greyCounter,
					bestAreaErrors, analysisErrors, time, s.length);
		}
	}

	private void analyzeCurrentFolder(ImagePlus image, int stackLooper) {
		image.unlock();
		System.out.println("unlocked ");

		if (crop != null) {
			image.setRoi(crop);
			new Resizer().run("crop");
			System.out.println("Resized");

		}

		new ImageConverter(image).convertToGray8();
		System.out.println("ImageConverted");

		// IJ.showMessage("Error", greyZone.toString() + " " +
		// blackZone.toString());

		if (analyzer == null)
			analyzer = new ParticleAnalyzer(DEBUGGING_MODE ? ParticleAnalyzer.SHOW_OUTLINES : 0,
					RECT + AREA + CENTROID + PERIMETER, table, 1000, Integer.MAX_VALUE, 0.1, 1);

		// Calibration cal = IJ.getImage().getCalibration();

		ImageProcessor ip = image.getProcessor();
		System.out.println("ImageProcessored");

		// new ContrastEnhancer().stretchHistogram(image, 10);

		// IJ.run(image, "Enhance Contrast", "saturated=0.35");
		if (DEBUGGING_MODE) {
			File ws = new File(workspace, UI.stripExtension(input.getName()));
			ws.mkdirs();
			File fOut = new File(ws, "debugging_" + UI.stripExtension(input.getName()));
			fOut.mkdirs();

			File pic = new File(fOut, "filename" + stackLooper + ".jpg");
			IJ.save(image, pic.getAbsolutePath());
		}
		double p = getThresholdValue(image, ip);
		System.out.println("getThresholdValued");

		// System.out.println("int i = " + p);
		ip.setThreshold(Math.max(64, p), 255, ImageProcessor.BLACK_AND_WHITE_LUT);

		boolean error = false;
		table.reset();
		analyzer.setHideOutputImage(true);
		if (!analyzer.analyze(image, ip)) {
			// errors.add(stackLooper);
			// errorsNames.add(image.getTitle());
			// IJ.showMessage("Error", "An error has occurred ");
			error = true;
			// IJ.showMessage("Warning", "Detected more than one area");
			analysisErrors++;

		}

		if (!error) {

			// Line2D line1 = new Line2D.Float(100, 100, 200, 200);
			// Line2D line2 = new Line2D.Float(150, 150, 150, 200);

			float areas[] = table.getColumn(ResultsTable.AREA);
			float x = -1, y = -1;
			if (areas != null) {

				float centroidX[] = table.getColumn(ResultsTable.X_CENTROID);
				float centroidY[] = table.getColumn(ResultsTable.Y_CENTROID);

				float area = -1;
				int areaInt = -1;

				for (int i = 0; i < areas.length; i++) {
					float areaLoop = areas[i];
					if (areaLoop >= area) {
						area = areaLoop;
						areaInt = i;
					}
				}

				if (areaInt > -1 && areaInt < centroidX.length) {

					x = centroidX[areaInt];
					y = centroidY[areaInt];

					if (greyZone.getBounds().contains(x, y)) {
						// IJ.showMessage("On grey zone");
						greyCounter++;
					} else
						blackCounter++;
				} else
					bestAreaErrors++;

			} else
				outsideTheViewCounter++;

			if (DEBUGGING_MODE) {
				ImagePlus img = analyzer.getOutputImage();

				if (x > -1 && y > -1)
					img.getProcessor().drawOval(Math.round(x), Math.round(y), 10, 10);
				img.getProcessor().drawRoi(greyZone);
				img.getProcessor().drawRoi(blackZone);
				File ws = new File(workspace, UI.stripExtension(input.getName()));
				ws.mkdirs();
				File fOut = new File(ws, "debugging_" + UI.stripExtension(input.getName()));
				fOut.mkdirs();
				IJ.run(img, "Invert", "");
				IJ.save(img,
						new File(fOut.getAbsolutePath(), "filename" + stackLooper + "_debug.jpg").getAbsolutePath());

			}

		} else
			analysisErrors++;

		// StringBuilder sb = new StringBuilder();
		// for (String s : errorsNames) {
		// sb.append(s);
		// sb.append("\n");
		// }
		// IJ.showMessage("Analyzed " + images + " images.\nGrey: " +
		// greyCounter + ", black: " + blackCounter
		// + ", outside-the-box: " + outsideTheViewCounter + ".\n" +
		// (bestAreaErrors + analysisErrors)
		// + " errors had occured during the process, of which " +
		// bestAreaErrors
		// + " are erros related to area measurements, " + analysisErrors + "
		// analysis errors.\n");

		time = System.currentTimeMillis() - time;

		IJ.run("Close All", "");
	}

	FinishAnalysisEvent finishFinishAnalysisListener;

	interface FinishAnalysisEvent {
		void onFinishedAnalysisEvent(int whiteCounter, int blackCounter, int greyCounter, int bestAreaErrors,
				int analysisErrors, long timeSpent, int frameCount);
	}

	File dir;
	JLabel statusbar;
	double min, max;

	public Main(File dir, Roi blackZone, Roi greyZone, Roi crop, FinishAnalysisEvent finishFinishAnalysisListener,
			long time, JLabel statusbar, double min, double max) {
		this.dir = dir;
		this.blackZone = blackZone;
		this.greyZone = greyZone;
		this.crop = crop;
		this.time = time;
		this.min = min;
		this.max = max;
		this.statusbar = statusbar;
		this.finishFinishAnalysisListener = finishFinishAnalysisListener;
	}

	@Override
	public int setup(String arg0, ImagePlus arg1) {

		if (arg0.equals("about")) {
			IJ.showMessageWithCancel("Darkion", "Automated CPP counter plugin");

			return DONE;
		}

		return NO_IMAGE_REQUIRED;
	}

}