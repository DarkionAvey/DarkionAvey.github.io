
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.DropMode;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;

import ij.IJ;
import ij.ImagePlus;
import ij.WindowManager;
import ij.gui.Roi;
import ij.io.LogStream;
import ij.io.Opener;
import ij.plugin.ContrastEnhancer;
import ij.plugin.FolderOpener;
import ij.plugin.Resizer;
import ij.plugin.filter.StackLabeler;
import ij.plugin.frame.ContrastAdjuster;
import ij.plugin.frame.PasteController;
import ij.plugin.frame.PlugInFrame;
import net.miginfocom.swing.MigLayout;

/**
 * This class implements utilizes ImageJ's threshold and particle analysis to
 * detect mouse location in CPP apparatus that's made from three compartments:
 * white, grey, and black. Since the mice we used were white, this class only
 * measures their presence in the grey and black compartments, then subtract the
 * time spent in each of the mentioned compartments to calculate the time in the
 * white compartment. Test time was fixed to 15 minutes.
 * 
 * 
 * Copyright - DarkionAvey / GPL license
 */

class ListItem {
	private String title = "";

	private String imagePath = "";

	private ImageIcon image;

	public ListItem(String title, String imagePath) {
		this.title = title;
		this.imagePath = imagePath;
	}

	public String getTitle() {
		return title;
	}

	public ImageIcon getImage() {
		if (image == null) {
			image = new ImageIcon(imagePath);
		}

		return image;
	}

	// Override standard toString method to give a useful result
	public String toString() {
		return title;
	}
}

class CellRenderer extends JLabel implements ListCellRenderer {
	private static final Color HIGHLIGHT_COLOR = new Color(0, 0, 128);

	public CellRenderer() {
		setOpaque(true);
		setIconTextGap(12);
	}

	public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
			boolean cellHasFocus) {
		ListItem entry = (ListItem) value;
		setText(entry.getTitle());

		// ImageIcon imageIcon = new
		// ImageIcon(entry.getImage().getImage().getScaledInstance(20, 20,
		// Image.SCALE_DEFAULT));

		setIcon(entry.getImage());
		if (isSelected) {
			setBackground(HIGHLIGHT_COLOR);
			setForeground(Color.white);
		} else {
			setBackground(Color.white);
			setForeground(Color.black);
		}
		return this;
	}
}

public class UI extends PlugInFrame {
	/**
	 * 
	 */
	String favWS = "C:\\Users\\darki\\Desktop\\x";
	private static final long serialVersionUID = 1L;
	private static Frame instance;
	JLabel field;
	JButton analyze;
	File workspace = new File(favWS), ffBat = new File("F:/ImageJ/plugins/Ab/ffmpeg/bin/ffmpeg.exe"),
			ffProbe = new File("F:/ImageJ/plugins/Ab/ffmpeg/bin/ffprobe.exe");
	private JTextField textField;
	long time;

	private String getFPS(File input) {

		try {
			String cmd = "\"" + ffProbe.getAbsolutePath() + "\""
					+ " -v error -select_streams v:0 -show_entries stream=avg_frame_rate -of default=noprint_wrappers=1:nokey=1 \""
					+ input.getAbsolutePath() + "\"";
			// System.out.println(cmd);

			Runtime rt = Runtime.getRuntime();
			Process proc = rt.exec(cmd);

			BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));

			StringBuilder line = new StringBuilder();
			// read the output from the command
			String s = null;
			while ((s = stdInput.readLine()) != null) {
				line.append(s);
				String l = line.toString();
				System.out.println("getFPS() l " + l);

				if (l.contains("/")) {
					String out[] = l.split("/");
					for (String m : out)
						System.out.println("getFPS() out[] " + m);
					int[] numbers = new int[out.length];
					if (numbers.length > 2)
						break;
					for (int i = 0; i < out.length; i++) {
						numbers[i] = Integer.valueOf(out[i]);
					}
					int fps = numbers[0] / numbers[1];
					return String.valueOf(fps);
				}
			}

			return s;

		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String errorOut = sw.toString();
			statusBar.setText("Error occured: getFPS");
			System.out.println("getFPS " + errorOut);

		}
		return String.valueOf(15);

	}

	private void exportMovie(File input) {

		File ws = new File(workspace, UI.stripExtension(input.getName()));
		if (!ws.exists())
			ws.mkdirs();
		File fOut = new File(ws, "debugging_" + UI.stripExtension(input.getName()));
		if (!fOut.exists())
			fOut.mkdirs();

		try {
			String cmd = "\"" + ffProbe.getAbsolutePath() + "\""
					+ "  -framerate 60 -pattern_type glob -i '*.jpg' -c:v libx264 \""
					+ new File(fOut, "debugging_output.mp4") + "\"";

			Runtime rt = Runtime.getRuntime();
			Process proc = rt.exec(cmd);

			BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));

			// read the output from the command
			String s = null;
			while ((s = stdInput.readLine()) != null) {

				System.out.println(s);

			}

		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String errorOut = sw.toString();
			statusBar.setText("Error occured: exportMovie");

			System.out.println(errorOut);

		}

	}

	private double getDurationInSec(File input) {

		try {
			String cmd = "\"" + ffProbe.getAbsolutePath() + "\"" + " -i \"" + input.getAbsolutePath()
					+ "\" -show_entries format=duration -v quiet -of csv=\"p=0\"";
			// System.out.println(cmd);

			Runtime rt = Runtime.getRuntime();
			Process proc = rt.exec(cmd);

			BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));

			BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
			StringBuilder line = new StringBuilder();
			// read the output from the command
			String s = null;
			while ((s = stdInput.readLine()) != null) {
				line.append(s);
				// System.out.println(s);
			}

			return Double.valueOf(line.toString());

		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String errorOut = sw.toString();
			statusBar.setText("Error occured: getDurationInSec");

			System.out.println("getDurationInSec " + errorOut);

		}
		return 0;

	}

	private static BufferedImage resizeImage(BufferedImage originalImage, int type) {
		BufferedImage resizedImage = new BufferedImage(40, 30, type);
		Graphics2D g = resizedImage.createGraphics();
		g.drawImage(originalImage, 0, 0, 40, 30, null);
		g.dispose();

		return resizedImage;
	}

	private File getThumbnail(File input) {
		File large = getSnapshot(input);
		File ws = new File(workspace, stripExtension(input.getName()));
		ws.mkdirs();
		File tmp = new File(ws, "temp");
		tmp.mkdirs();
		File output = new File(tmp, "screensnap_" + stripExtension(input.getName()) + "_thumb.jpg");
		if (output.exists())
			return output;
		try {
			BufferedImage originalImage = ImageIO.read(large);
			int type = originalImage.getType() == 0 ? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
			BufferedImage resizeImageJpg = resizeImage(originalImage, type);
			ImageIO.write(resizeImageJpg, "jpg", output);
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String errorOut = sw.toString();
			statusBar.setText("Error occured: getThumbnail");

			System.out.println("getThumbnail " + errorOut);

		}
		return output;

	}

	private File getSnapshot(File input) {
		File ws = new File(workspace, stripExtension(input.getName()));
		ws.mkdirs();
		File tmp = new File(ws, "temp");
		tmp.mkdirs();
		File output = new File(tmp, "screensnap_" + stripExtension(input.getName()) + ".jpg");
		if (output.exists())
			return output;
		try {
			double duration = getDurationInSec(input);
			double sec = 600;
			String time = "00:10:00";
			if (sec > duration)
				time = convertSecondsToHMmSs((int) duration);
			String cmd = "\"" + ffBat.getAbsolutePath() + "\"" + " -ss " + time + " -t 1 -i \""
					+ input.getAbsolutePath() + "\" -f mjpeg \"" + output.getAbsolutePath() + "\"";

			ProcessBuilder builder = new ProcessBuilder(cmd);
			builder.redirectErrorStream(true);
			Process p = builder.start();
			BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line;
			while (true) {
				line = r.readLine();
				if (line == null) {
					break;
				}
				// System.out.println(line);
			}

		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String errorOut = sw.toString();
			statusBar.setText("Error occured: getSnapshot");

			System.out.println("getSnapshot " + errorOut);

		}
		return output;

	}

	private void invalidateAnalyzeButton() {

		ffbatButton.setEnabled(workspace != null && workspace.isDirectory());
		list.setEnabled(ffbatButton.isEnabled() && (ffBat != null && ffBat.exists()));
		captureButton.setEnabled(list.isEnabled() && list.getModel().getSize() > 0);
		analyze.setEnabled(ffbatButton.isEnabled() && list.isEnabled() && captureButton.isEnabled()
				&& list.getModel() != null && list.getModel().getSize() > 0
				&& (ffBat != null && ffBat.exists() && ffBat.getName().contains("ffmpeg.exe"))
				&& (workspace != null || workspace.exists() || workspace.isDirectory())
				&& (list.getModel().getSize() == cropZones.size()));

	}

	ArrayList<Roi> blackZones = new ArrayList<Roi>();
	ArrayList<Roi> greyZones = new ArrayList<Roi>();
	ArrayList<Roi> cropZones = new ArrayList<Roi>();
	ArrayList<Integer> startingPoints = new ArrayList<Integer>();
	ArrayList<Double> mins = new ArrayList<Double>();
	ArrayList<Double> max = new ArrayList<Double>();
	ArrayList<Integer> endingPoints = new ArrayList<Integer>();

	public static int convertMmSsToSeconds(String mmss) {
		String[] values = mmss.split(",");

		return (Integer.parseInt(values[0]) * 60) + Integer.parseInt(values[1]);
	}

	public static String convertSecondsToHMmSs(long seconds) {
		long s = seconds % 60;
		long m = (seconds / 60) % 60;
		return String.format("%02d:%02d", m, s);
	}

	Opener staticOpener = new Opener();

	private void start() {
		if (!analyze.isEnabled())
			return;
		analyze.setEnabled(false);
		isWorking = true;
		new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 0; i < list.getModel().getSize(); i++) {
					time = System.currentTimeMillis();
					list.setSelectedIndex(i);

					final float finalI = i + 1;
					ListItem item = (ListItem) list.getModel().getElementAt(i);
					String dir = item.getTitle();
					try {

						final File input = new File(dir);

						if (!input.exists())
							continue;

						final File ws = new File(workspace, stripExtension(input.getName()));
						ws.mkdirs();
						File tmp = new File(ws, "temp");
						tmp.mkdirs();

						final File output = new File(tmp, "filename%01d.jpg");
						int index = list.getSelectedIndex();

						double duration = getDurationInSec(input);
						int frames = (int) (duration * Integer.valueOf(textField.getText()));
						int fps = Integer.parseInt(textField.getText());

						if (tmp.exists()) {
							output.getParentFile().mkdirs();
							String cmd = "\"" + ffBat.getAbsolutePath() + "\"" + " -i \"" + input.getAbsolutePath()
									+ "\" -vf fps="
									+ (Double.parseDouble(textField.getText())
											/ (chckbxXFastForward.isSelected() ? 2 : 1))
									+ " \"" + output.getAbsolutePath() + "\"";

							// System.out.println(cmd);

							// System.out.println("frames " + frames);

							ProcessBuilder builder = new ProcessBuilder(cmd);
							builder.redirectErrorStream(true);
							Process p = builder.start();
							BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
							String line;
							while (true) {
								line = r.readLine();
								int exportedFrames = output.getParentFile().list().length;
								int progress = (int) (((float) exportedFrames
										* (finalI / (float) list.getModel().getSize()) / (float) frames) * 100);
								statusBar.setText("Extracted " + progress + "% of frames. (" + exportedFrames + "/"
										+ (frames / (chckbxXFastForward.isSelected() ? 2 : 1)) + ")");

								if (line == null || exportedFrames > frames) {
									break;
								}
								// System.out.println(line);
							}

							if (endingPoints.get(i) > -1) {
								int belowFrames = startingPoints.get(i) * fps;
								belowFrames = Math.max(0, belowFrames);

								int aboveFrames = endingPoints.get(i) * fps;
								statusBar.setText("Trimming time points @ " + startingPoints.get(i) + " - "
										+ endingPoints.get(i));

								for (int z = 0; z < belowFrames; z++) {
									File pic = new File(tmp, "filename" + z + ".jpg");
									if (pic.exists())
										pic.delete();
								}
								for (int m = aboveFrames; m < frames; m++) {
									File pic = new File(tmp, "filename" + m + ".jpg");
									if (pic.exists())

										pic.delete();
								}
							}

						}

						try {
							Main analyzer = new Main(output.getParentFile(), blackZones.get(index),
									greyZones.get(index), cropZones.get(index), new Main.FinishAnalysisEvent() {

										@Override
										public void onFinishedAnalysisEvent(int whiteCounter, int blackCounter,
												int greyCounter, int bestAreaErrors, int analysisErrors, long timeSpent,
												int frameCount) {
											statusBar.setText("Idle");

											try {
												File txt = new File(ws, "results.txt");
												final PrintWriter out = new PrintWriter(txt);

												out.println("Results for: "
														+ stripExtension(stripExtension(input.getName())));
												out.println("");

												out.println("Fast-forward results:" + chckbxXFastForward.isSelected());
												out.println("");

												out.println("White compartment time: "
														+ (whiteCounter / Integer.valueOf(textField.getText()))
														+ " seconds. " + "("
														+ convertSecondsToHMmSs(
																whiteCounter / Integer.valueOf(textField.getText()))
														+ " | " + whiteCounter + " hits)");
												out.println("Black compartment time: "
														+ (blackCounter / Integer.valueOf(textField.getText()))
														+ " seconds. " + "("
														+ convertSecondsToHMmSs(
																blackCounter / Integer.valueOf(textField.getText()))
														+ " | " + blackCounter + " hits)");

												out.println("Grey compartment time: "
														+ (greyCounter / Integer.valueOf(textField.getText()))
														+ " seconds. " + "("
														+ convertSecondsToHMmSs(
																greyCounter / Integer.valueOf(textField.getText()))
														+ " | " + greyCounter + " hits)");

												out.println("_________");
												out.println("");

												out.println("Area detection errors: " + bestAreaErrors);

												out.println("Analysis errors: " + analysisErrors);

												out.println(
														"Computing time: " + convertSecondsToHMmSs(timeSpent / 1000));

												out.println("Total frames processed: " + frameCount + " ("
														+ (frameCount / Integer.valueOf(textField.getText()))
														+ " seconds | "
														+ convertSecondsToHMmSs(
																(frameCount / Integer.valueOf(textField.getText())))
														+ ")");

												out.close();
												IJ.run("Close All", "");

												delete(output.getParentFile());
												// exportMovie(new
												// File(workspace,
												// input.getName()),
												// new File(workspace, "debug_"
												// +
												// input.getName()));

												invalidateAnalyzeButton();
												staticOpener.open(txt.getAbsolutePath());
												if (finalI == list.getModel().getSize()) {
													captureButton.setText("Capture");
												}

												// exportMovie(input);
											} catch (Exception e) {
												StringWriter sw = new StringWriter();
												PrintWriter pw = new PrintWriter(sw);
												e.printStackTrace(pw);
												String errorOut = sw.toString();
												statusBar.setText("Error occured: onFinishedAnalysisEvent");

												System.out.println("onFinishedAnalysisEvent " + errorOut);

											}

										}
									}, time, statusBar, mins.get(i), max.get(i));
							analyzer.setWorkspace(workspace);
							analyzer.setInputFile(input);

							statusBar.setText("Importing frames");

							FolderOpener opner = new FolderOpener();
							opner.openAsVirtualStack(true);

							final ImagePlus img = opner.openFolder(output.getParentFile().getAbsolutePath());
							img.show();
							statusBar.setText("Analyzing data");

							analyzer.analyze();

						} catch (Exception ee) {
							StringWriter sw = new StringWriter();
							PrintWriter pw = new PrintWriter(sw);
							ee.printStackTrace(pw);
							String errorOut = sw.toString();
							statusBar.setText("Error occured: analyszer");

							System.out.println("analyszer " + errorOut);

						}
					} catch (Exception e) {
						StringWriter sw = new StringWriter();
						PrintWriter pw = new PrintWriter(sw);
						e.printStackTrace(pw);
						String errorOut = sw.toString();
						statusBar.setText("Error occured: start ");

						System.out.println("start " + errorOut);

					}
				}
				isWorking = false;

			}
		}).start();
	}

	JButton captureButton;
	JList list;
	JButton ffbatButton;

	private void loadImageThumbForCapturing() {
		ListItem item = (ListItem) list.getSelectedValue();
		File snapShot = getSnapshot(new File(item.getTitle()));
		if (!snapShot.exists()) {
			System.out.println("File doesn't exist " + snapShot.getName());
			return;
		}

		ImagePlus imp = IJ.openImage(snapShot.getAbsolutePath());
		imp.show();
		IJ.setTool(0); // Rectangle tool
		captureButton.setEnabled(true);

		captureButton.setText(String.format("Capture %s for %s", "grey zone",
				stripExtension(new File(((ListItem) list.getSelectedValue()).getTitle()).getName())));
	}

	boolean isWorking = false;

	static String stripExtension(String str) {
		// Handle null case specially.

		if (str == null)
			return null;

		// Get position of last '.'.

		int pos = str.lastIndexOf(".");

		// If there wasn't any '.' just return the string as is.

		if (pos == -1)
			return str;

		// Otherwise return the string, up to the dot.

		return str.substring(0, pos);
	}

	JCheckBox chckbxWhitePanelTo;
	JCheckBox chckbxXFastForward;
	private JLabel statusBar;

	public UI() {
		super("Batch CPP counter");
		if (instance != null) {
			WindowManager.toFront(instance);
			return;
		}
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String errorOut = sw.toString();
			statusBar.setText("Error occured: UI");

			System.out.println(" UI " + errorOut);

		}
		setAlwaysOnTop(true);
		// setSize(3, 343);
		WindowManager.addWindow(this);
		instance = this;
		IJ.register(PasteController.class);
		JPanel panel = new JPanel();

		add(panel);
		panel.setLayout(new MigLayout("", "[108.00px,grow][][142px][][97.00px,grow,left]",
				"[14px][23px][14.00px][][133.00][][][][][grow][][31.00]"));

		JLabel lblNewLabel_1 = new JLabel("Temporary workspace");
		panel.add(lblNewLabel_1, "cell 0 0 2 1,alignx left,aligny top");

		final JLabel lblFfmpegLocation = new JLabel("ffmpeg.exe location");
		panel.add(lblFfmpegLocation, "cell 2 0");

		field = new JLabel("FPS");
		panel.add(field, "flowx,cell 4 0,alignx left,aligny bottom");

		final JButton Browse = new JButton("Browse");
		panel.add(Browse, "cell 0 1,growx,aligny top");

		ffbatButton = new JButton("Browse");
		ffbatButton.setEnabled(false);
		panel.add(ffbatButton, "cell 2 1,growx");
		ffbatButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				JFileChooser chooser = new JFileChooser();
				chooser.setCurrentDirectory(new java.io.File(".\\plugins\\Ab\\ffmpeg\\bin\\"));
				chooser.setDialogTitle("Browse for ff-pffmpeg.exe");
				chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

				chooser.setAcceptAllFileFilterUsed(false);

				if (chooser.showOpenDialog(instance) == JFileChooser.APPROVE_OPTION
						&& chooser.getSelectedFile().getName().contains("ffmpeg.exe")) {
					ffBat = chooser.getSelectedFile();
					System.out.println(ffBat.getAbsolutePath());

					ffProbe = new File(ffBat.getParent(), "ffprobe.exe");
					ffbatButton.setText(chooser.getSelectedFile().getName());
				} else {
					Browse.setText("Browse");
				}

				invalidateAnalyzeButton();

			}
		});

		textField = new JTextField();
		textField.setEnabled(false);
		panel.add(textField, "cell 4 1,growx");
		textField.setColumns(10);

		JLabel lblNewLabel = new JLabel("File(s)");
		panel.add(lblNewLabel, "cell 0 3,alignx left,aligny top");

		JScrollPane pane = new JScrollPane();
		pane.setPreferredSize(new Dimension(180, 150));
		list = new JList();
		list.setEnabled(false);

		list.setCellRenderer(new CellRenderer());
		list.setDropMode(DropMode.INSERT);

		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		new FileDrop(list, new FileDrop.Listener() {
			public void filesDropped(final File[] files) {
				if (!list.isEnabled())
					return;
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					greyZones.clear();
					blackZones.clear();
					cropZones.clear();

					list.removeAll();
					ListItem[] items = new ListItem[files.length];

					for (int i = 0; i < files.length; i++) {
						String fileName = files[i].getName();
						if (fileName.contains("@") && fileName.contains("-") && fileName.contains(",")) {

							String times = fileName.substring(fileName.indexOf("@"));
							times = times.replaceAll("\\s+", "");
							times = times.replace("@", "");

							String[] values = times.split("-");

							int[] valuesInt = new int[values.length];
							valuesInt[0] = convertMmSsToSeconds(values[0]);
							valuesInt[1] = convertMmSsToSeconds(stripExtension(values[1]));
							startingPoints.add(valuesInt[0]);
							endingPoints.add(valuesInt[1]);

							// System.out.println(valuesInt[0] + " shit " +
							// valuesInt[1]);

						} else {
							startingPoints.add(-1);
							endingPoints.add(-1);

						}
						items[i] = new ListItem(files[i].getAbsolutePath(), getThumbnail(files[i]).getAbsolutePath());
						textField.setText(getFPS(files[i]));

						cropZones.add(new Roi(new Rectangle()));
						greyZones.add(new Roi(new Rectangle()));
						blackZones.add(new Roi(new Rectangle()));

					}
					list.setListData(items);

					analyze.setText(String.format("Analyze %s file(s)", files.length));
					captureButton.setText("Capture");
					captureButton.setEnabled(true);

					invalidateAnalyzeButton();
					
				}
			}).run();
			} // end filesDropped
		});
		pane.setViewportView(list);
		panel.add(pane, "cell 0 4 5 1,grow");

		captureButton = new JButton("Capture");
		captureButton.setEnabled(false);
		captureButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				String text = captureButton.getText();

				if (text.equals("Capture")) {
					list.setSelectedIndex(list.getSelectedIndex() == -1 ? 0 : (list.getSelectedIndex() + 1));
					loadImageThumbForCapturing();

				}

				int index = list.getSelectedIndex();

				if (text.contains("grey zone") && IJ.getImage().getRoi() != null) {
					greyZones.set(index, IJ.getImage().getRoi());
					blackZones.set(index, IJ.getImage().getRoi());
					IJ.getImage().deleteRoi();
					captureButton.setText(String.format("Capture %s for %s", "cropping zone",
							stripExtension(new File(((ListItem) list.getSelectedValue()).getTitle()).getName())));
				} else if (text.contains("cropping zone") && IJ.getImage().getRoi() != null) {
					cropZones.set(index, IJ.getImage().getRoi());

					if (cropZones.get(index) != null) {
						Rectangle newGreyRect, newBlackRect;
						if (!chckbxWhitePanelTo.isSelected()) {
							newGreyRect = new Rectangle(0, 0, greyZones.get(index).getBounds().width,
									cropZones.get(index).getBounds().height);

							newBlackRect = new Rectangle(newGreyRect.width, 0,
									cropZones.get(index).getBounds().width - newGreyRect.width,
									cropZones.get(index).getBounds().height);
							System.out.println(newGreyRect.toString() + " " + newBlackRect.toString() + " "
									+ cropZones.get(index).getBounds().toString());
						} else {
							newGreyRect = new Rectangle(
									cropZones.get(index).getBounds().width - greyZones.get(index).getBounds().width, 0,
									cropZones.get(index).getBounds().width, cropZones.get(index).getBounds().height);

							newBlackRect = new Rectangle(0, 0,
									cropZones.get(index).getBounds().width - newGreyRect.width,
									cropZones.get(index).getBounds().height);
						}
						greyZones.set(index, new Roi(newGreyRect));
						blackZones.set(index, new Roi(newBlackRect));

					}

					new Resizer().run("crop");
					IJ.getImage().deleteRoi();
					captureButton.setText(String.format("Capture %s for %s", "brightness/contrast",
							stripExtension(new File(((ListItem) list.getSelectedValue()).getTitle()).getName())));

					mins.add(0.0);
					max.add(0.0);
					new ContrastAdjuster().run("balance");

				} else if (text.contains("brightness")) {
					if (IJ.getProcessor().getMin() == 0 || IJ.getProcessor().getMax() == 255) {
						statusBar.setText("Min and max shouldn't be 0,255 respectively");
						return;
					}
					mins.set(index, IJ.getProcessor().getMin());
					max.set(index, IJ.getProcessor().getMax());

					if (index < list.getModel().getSize())
						captureButton.setText("Capture");
					else {
						captureButton.setText("Done");
						captureButton.setEnabled(false);
					}
					System.out.println("min " + mins.get(index) + " max " + max.get(index));

					IJ.getImage().close();
				}
				invalidateAnalyzeButton();

				if (captureButton.getText().equalsIgnoreCase("done"))
					captureButton.setEnabled(false);

				// System.out.println(IJ.getImage().getRoi());

			}
		});

		chckbxWhitePanelTo = new JCheckBox("White panel on right");
		panel.add(chckbxWhitePanelTo, "cell 2 5");

		chckbxXFastForward = new JCheckBox("x2 fast forward");
		chckbxXFastForward.setSelected(true);
		panel.add(chckbxXFastForward, "cell 4 5");
		panel.add(captureButton, "cell 0 7 5 1,growx");

		JLabel lblInstructions = new JLabel("Instructions");
		panel.add(lblInstructions, "cell 0 8");

		JTextArea txtrFirstYouNeed = new JTextArea();
		txtrFirstYouNeed.setWrapStyleWord(true);
		txtrFirstYouNeed.setRows(5);
		txtrFirstYouNeed.setLineWrap(true);
		txtrFirstYouNeed.setEnabled(false);
		txtrFirstYouNeed.setEditable(false);
		txtrFirstYouNeed.setBackground(SystemColor.menu);
		txtrFirstYouNeed.setFont(new Font("Tahoma", Font.PLAIN, 11));
		txtrFirstYouNeed.setText(
				"� Locate an empty folder where the app will extract the video frames. Make sure you have enough space on your disk."
						+ "\n� Locate ffmpeg.exe which you have to download from the offical website."
						+ "\n� Optional: specify the starting and ending times of the video by adding @mm,ss-mm,ss (e.g. 'test @5,00-10,41.mp4') to its name"

						+ "\n� Drag and drop video files onto the 'files' area specified. All video types are supported"
						+ "\n� Click capture button to start highlighting grey, and cropping zones respectivly for all added videos. Cropping zone is the detection area."
						+ "\n� Click analyze to start"
						+ "\n� It will take long time. Don't disturb or terminate the app. Results will be printed to a text file in the workspace folder which you assigned in the first step."
						+ "\n� x2 fast forward option skips odd frames, which reduces processing time (and to lesser extent accuracy)"

						+ "\n\nBy DarkionAvey"

		);
		panel.add(txtrFirstYouNeed, "cell 0 9 5 1,grow");

		statusBar = new JLabel("Idle");
		panel.add(statusBar, "cell 0 11 4 1,growx");
		analyze = new JButton(String.format("Analyze %s file(s)", 0));
		analyze.setEnabled(false);
		panel.add(analyze, "cell 4 11,grow");

		analyze.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				start();

			}
		});
		Browse.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				JFileChooser chooser = new JFileChooser();
				chooser.setCurrentDirectory(new File(favWS));
				chooser.setDialogTitle("Browse for workspace folder");
				chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				chooser.setAcceptAllFileFilterUsed(false);

				if (chooser.showOpenDialog(instance) == JFileChooser.APPROVE_OPTION) {
					Browse.setText(chooser.getSelectedFile().getName());
					workspace = chooser.getSelectedFile();

				} else {
					Browse.setText("Browse");
				}

				invalidateAnalyzeButton();

			}
		});
		pack();

		WindowListener exitListener = new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				if (!isWorking)
					System.exit(1);
			}
		};
		addWindowListener(exitListener);

		setVisible(true);

		LogStream.redirectSystem();
		invalidateAnalyzeButton();
		System.out.println();

	}

	private void delete(File f) {
		if (f.isDirectory()) {
			for (File f1 : f.listFiles()) {
				delete(f1);
			}
		} else
			f.delete();
	}

}