Defect detection Matlab code by Zouhir Wakaf and Hamid A. Jalab is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.
__________________________________


INSTRUCTIONS:
=============
-Type "Z_H_test" in the command window (without quotation marks!)
-Press enter
-Then type the name of testing imge e.g. e3.png
-Press enter 